import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsuarioComponent } from './usuario/usuario.component';
import { AdminComponent } from './admin/admin.component';
import { CatalogoComponent } from './catalogo/catalogo.component';
import { ListaComponent } from './lista/lista.component';

const routes: Routes = [
  {
    path:'user',
    component:UsuarioComponent
  },
  {
    path:'admin',
    component:AdminComponent
  },
  {
    path:'cat',
    component:CatalogoComponent
  },
  {
    path:'lista',
    component:ListaComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
