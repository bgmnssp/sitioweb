
import { HttpClient } from '@angular/common/http';
import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {

  producto={cod:0,nom:"",pre:0,sto:0}
  productos=[
    {cod:1,nom:"kukri",pre:30000,sto:40},
    {cod:2,nom:"machete",pre:10000,sto:60},
    {cod:3,nom:"carpa",pre:300000,sto:10},
    {cod:4,nom:"soga",pre:1400,sto:600},
    {cod:5,nom:"repelente",pre:7000,sto:50},
    {cod:6,nom:"hacha",pre:20000,sto:35},
    {cod:7,nom:"cooler",pre:35500,sto:24},
    {cod:8,nom:"cuchillo sup",pre:12000,sto:45},
    {cod:9,nom:"linterna",pre:7000,sto:130},
    {cod:10,nom:"olla",pre:7600,sto:65}
  ];

  eprods(){
    return this.productos.length>0;
  }

  eliminar(cod:number){ 
    for (let index = 0; index < this.productos.length; index++) {
      if (this.productos[index].cod==cod) {
        this,this.productos.splice(index,1);
        return;
      }
    }
  }
  select(producto:{cod:number,nom:string,pre:number,sto:number}){
    this.producto.cod=producto.cod;
    this.producto.nom=producto.nom;
    this.producto.pre=producto.pre;
    this.producto.sto=producto.sto;
  }


  agregar(){
    var c=0;
    if(this.producto.cod==0){
      alert("ingrese codigo diferente a 0");
      return;      
    }
    for (let i = 0; i < this.productos.length; i++) {
      
      if (this.productos[i].cod==this.producto.cod) {
        alert("producto existente")
        c=1;
        break;
      }
      
    }
    if (c==0) {
      this.productos.push({cod:this.producto.cod,nom:this.producto.nom,pre:this.producto.pre,sto:this.producto.sto});
      c=0;
    }

    this.producto.cod=0;
    this.producto.nom="";
    this.producto.pre=0;
    this.producto.sto=0;
  }


  modificar(){
    for (let index = 0;  index < this.productos.length; index++) {
      if (this.productos[index].cod==this.producto.cod) {

        this.productos[index].nom=this.producto.nom;
        this.productos[index].pre=this.producto.pre;
        this.productos[index].sto=this.producto.sto;
        return;
      }
    }
    alert("no existe el producto");
  }


  buscar(){
    for (let i = 0; i < this.productos.length; i++) {
      if(this.productos[i].cod==this.producto.cod){

        this.producto.nom=this.productos[i].nom;
        this.producto.pre=this.productos[i].pre;
        this.producto.sto=this.productos[i].sto;
      }
      
    }
  }

  
}
