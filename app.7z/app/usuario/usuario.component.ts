import { Component } from '@angular/core';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.css']
})
export class UsuarioComponent {

  check(){
    var region,comuna,callenum,mail,passwrd,chek;

    mail=document.getElementById("Email");
    passwrd=document.getElementById("Password");
    region=document.getElementById("reg");
    comuna=document.getElementById("com");
    callenum=document.getElementById("canum");
    chek=document.getElementById("chek");

    if(mail==null){
      alert("campo requerido");
      window.location.href="../app/app.component.html";
    }
    if(passwrd==null){
      alert("campo requerido");
      window.location.href="../app/app.component.html";
    }
    if(region==null){
      alert("campo requerido");
      window.location.href="../app/app.component.html";
    }
    if(comuna==null){
      alert("campo requerido");
      window.location.href="../app/app.component.html";
    }
    if(callenum==null){
      alert("campo requerido");
      window.location.href="../app/app.component.html";
    }
    
    
  }
}
